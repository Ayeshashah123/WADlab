//Task1
function changeClass() {
    var paragraph = document.getElementById("myPara");
    
        console.log("Old class:", paragraph.className);
    
        paragraph.className = "XYZ";
        console.log("New class:", paragraph.className);
    }
    
     
    //Task2
    const logIn = document.createElement("button");
        logIn.textContent = "LogIn";
        logIn.style.backgroundColor = "red";  
        logIn.style.color = "black";  
        logIn.style.fontSize = "15px"; 
        logIn.style.padding = "20px 25px";  
    
        logIn.onmouseover=()=> {
            console.log("Button inserted in start outside the body element");
        };
    document.documentElement.insertBefore(logIn, document.body);
    
    //Task3
    function addNewStyle() {
        const para = document.querySelector('.myclass');
    
        para.classList.add('newStyling');
    }