//Task 1
var heading = document.getElementById("heading");
heading.innerHTML += " - Syeda Ayesha Fatima (53953)";
//Task 2
var containers = document.getElementsByClassName("Container");
var texts = ["Syeda Ayesha Fatima", "BSCS-4", "Riphah International University"];
for (var i = 0; i < containers.length; i++) {
    containers[i].innerHTML = texts[i];
}